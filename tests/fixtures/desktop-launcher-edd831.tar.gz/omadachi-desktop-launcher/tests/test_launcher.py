import configparser
from contextlib import redirect_stdout
import io
from pathlib import Path
import runpy
import tempfile
import unittest
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1]
installer=runpy.run_path(str(ROOT/'install_launcher.py'))
wrapper=runpy.run_path(str(ROOT/'payload/omadachi-panel'))

class LauncherTests(unittest.TestCase):
    def test_readonly_check_does_not_create_home_entries(self):
        with tempfile.TemporaryDirectory() as temporary:
            home=Path(temporary)/'new-home';rows=installer['inspect'](home)
            self.assertEqual(len(rows),3);self.assertTrue(all(row['status']=='missing' for row in rows));self.assertFalse(home.exists())
    def test_install_exact_desktop_wrapper_and_icon_then_idempotent(self):
        with tempfile.TemporaryDirectory() as temporary:
            home=Path(temporary)/'user with space';result=installer['install'](home)
            self.assertTrue(result['installed']);self.assertFalse(result['media_started'])
            entry=home/'.local/share/applications/com.omadochi.host.desktop'
            config=configparser.ConfigParser(interpolation=None);config.optionxform=str;config.read(entry)
            values=config['Desktop Entry'];self.assertEqual(values['Name'],'Omadachi');self.assertEqual(values['Terminal'],'false')
            self.assertEqual(values['Icon'],'com.omadochi.host');self.assertEqual(values['Exec'],'"'+str(home/'.local/bin/omadachi-panel')+'"')
            before={row['path']:Path(row['path']).stat().st_mtime_ns for row in result['files']}
            self.assertTrue(installer['install'](home)['installed'])
            self.assertEqual(before,{row['path']:Path(row['path']).stat().st_mtime_ns for row in result['files']})
    def test_existing_user_desktop_file_is_never_replaced_or_other_files_written(self):
        with tempfile.TemporaryDirectory() as temporary:
            home=Path(temporary);entry=home/'.local/share/applications/com.omadochi.host.desktop'
            entry.parent.mkdir(parents=True);entry.write_text('user existing launcher')
            result=installer['install'](home);self.assertFalse(result['installed']);self.assertEqual(result['error'],'existing_file_conflict')
            self.assertEqual(entry.read_text(),'user existing launcher');self.assertFalse((home/'.local/bin/omadachi-panel').exists())
    def test_symlink_conflict_does_not_overwrite_target(self):
        with tempfile.TemporaryDirectory() as temporary:
            home=Path(temporary);target=home/'user';target.write_text('keep')
            entry=home/'.local/share/applications/com.omadochi.host.desktop';entry.parent.mkdir(parents=True);entry.symlink_to(target)
            self.assertFalse(installer['install'](home)['installed']);self.assertEqual(target.read_text(),'keep')
    def test_local_wrapper_uses_only_fixed_omarchy_summon_no_media_or_credentials(self):
        with patch('sys.argv',['omadachi-panel']),patch('subprocess.run') as run,redirect_stdout(io.StringIO()) as output:
            run.return_value.returncode=0;self.assertEqual(wrapper['main'](),0)
            self.assertEqual(run.call_args.args[0],('omarchy-shell','shell','summon','com.omadochi.host','{"view":"overview"}'))
            self.assertFalse(run.call_args.kwargs['shell']);self.assertEqual(run.call_args.kwargs['env']['OMARCHY_PATH'],'/usr/share/omarchy')
            self.assertIn('"requested": true',output.getvalue());self.assertNotIn('opened',output.getvalue())
    def test_wrapper_refuses_extra_arguments_and_reports_unavailable(self):
        with patch('sys.argv',['omadachi-panel','unexpected']),patch('subprocess.run') as run,redirect_stdout(io.StringIO()):
            self.assertEqual(wrapper['main'](),2);run.assert_not_called()
        with patch('sys.argv',['omadachi-panel']),patch('subprocess.run',side_effect=OSError()),redirect_stdout(io.StringIO()) as out:
            self.assertEqual(wrapper['main'](),1);self.assertIn('omarchy_panel_unavailable',out.getvalue())

if __name__=='__main__':unittest.main()
