#!/usr/bin/env python3
"""Install only an absent or byte-identical user-level Omadachi desktop entry.

--check is read-only. --install creates three owned entry/icon/wrapper files;
existing differing files are never replaced. No desktop/media service is started.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import stat
import sys

ROOT=Path(__file__).resolve().parent

def sha(data):return hashlib.sha256(data).hexdigest()

def desktop_exec(path):
    text=str(path)
    if any(c in text for c in '\0\n\r'):raise ValueError('invalid_home_path')
    # Desktop Exec quoting is not shell evaluation; the executable has no args.
    quoted='"'+''.join(('\\'+c if c in '\\"`$' else '%%' if c=='%' else c) for c in text)+'"'
    return quoted.replace('\\','\\\\')


def payload(home):
    wrapper=home/'.local/bin/omadachi-panel'
    entry=('''[Desktop Entry]
Type=Application
Version=1.0
Name=Omadachi
GenericName=Host control panel
Comment=Open the local Omadachi control panel
Comment[zh_CN]=打开本机 Omadachi 控制面板
Exec='''+desktop_exec(wrapper)+'''
Icon=com.omadochi.host
Terminal=false
Categories=Utility;System;
Keywords=Omadachi;Omadochi;Remote;Host;
StartupNotify=false
X-Omadachi-Managed=true
''').encode()
    return {
        wrapper:((ROOT/'payload/omadachi-panel').read_bytes(),0o755),
        home/'.local/share/icons/hicolor/scalable/apps/com.omadochi.host.svg':((ROOT/'payload/com.omadochi.host.svg').read_bytes(),0o644),
        home/'.local/share/applications/com.omadochi.host.desktop':(entry,0o644)}

def inspect(home):
    rows=[]
    for path,(data,mode) in payload(home).items():
        if path.is_symlink():state='conflict'
        elif not path.exists():state='missing'
        elif path.is_file() and path.read_bytes()==data and stat.S_IMODE(path.stat().st_mode)==mode:state='installed'
        else:state='conflict'
        rows.append({'path':str(path),'status':state,'sha256':sha(data),'mode':oct(mode)})
    return rows

def install(home):
    expected=payload(home);before=inspect(home)
    if any(row['status']=='conflict' for row in before):
        return {'installed':False,'error':'existing_file_conflict','files':before}
    for path,(data,mode) in expected.items():
        if path.exists():continue
        path.parent.mkdir(parents=True,exist_ok=True)
        # Exclusive creation prevents a race from overwriting a new user file.
        fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL,mode)
        with os.fdopen(fd,'wb') as stream:
            os.fchmod(stream.fileno(),mode);stream.write(data);stream.flush();os.fsync(stream.fileno())
    after=inspect(home)
    return {'installed':all(row['status']=='installed' for row in after),'files':after,
            'surface':'local_plugin_panel','existing_files_overwritten':False,'media_started':False,'host_services_restarted':False}

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--home',type=Path,default=Path.home())
    modes=parser.add_mutually_exclusive_group(required=True);modes.add_argument('--check',action='store_true');modes.add_argument('--install',action='store_true')
    args=parser.parse_args();home=args.home.expanduser().absolute()
    result={'files':inspect(home),'read_only':True} if args.check else install(home)
    print(json.dumps(result,indent=2));return 0 if args.check or result.get('installed') else 1
if __name__=='__main__':raise SystemExit(main())
