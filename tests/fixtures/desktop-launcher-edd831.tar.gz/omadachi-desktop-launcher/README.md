# User-level Omadachi application launcher

This small delivery adds a discoverable `Omadachi` entry to the user's desktop
application directory. It opens the local Omadachi plugin panel via the existing
fixed Omarchy summon operation. It does not route to a lease owner, start
Sunshine/Moonlight/media, read credentials, or require a core daemon connection.
It reuses the existing Omadachi SVG icon from the installed plugin source.

Main-owned installation, as the normal desktop user:

    python3 install_launcher.py --check
    python3 install_launcher.py --install

The three destinations are:

- ~/.local/bin/omadachi-panel
- ~/.local/share/icons/hicolor/scalable/apps/com.omadochi.host.svg
- ~/.local/share/applications/com.omadochi.host.desktop

The wrapper runs exactly `omarchy-shell shell summon com.omadochi.host` with
`{"view":"overview"}` as a fixed argument and OMARCHY_PATH=/usr/share/omarchy.
It never invokes a shell string or executes supplied arguments. Its receipt says
requested, not a claim that the GUI was visibly opened. A missing/failed shell
returns an explicit failure.

--check performs no writes. --install creates only missing files with exclusive
creation; any existing differing file or symlink produces a conflict and is
left untouched. Identical installations are a no-op. No service restart, default
handler change, unrelated launcher change or cache cleanup is performed.

Six local tests cover isolated install/readback/idempotence, user-file/symlink
preservation and actual wrapper fixed-argv invocation through a test process seam.
They do not prove the live Omarchy directory or visible panel. Main should check
that the user-level desktop entry appears in the actual Apps catalog and launch
it once to observe the local plugin panel; this is not an already-completed
installation-journey claim.
